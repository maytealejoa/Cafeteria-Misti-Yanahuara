# ☕ Café Misti — Sitio Web Institucional & Carta Digital

> Sitio web estático (HTML5 semántico y CSS3 responsive) para la cafetería de especialidad **Café Misti** ubicada en Yanahuara, Arequipa, Perú. Proyecto desarrollado bajo metodologías ágiles y prácticas DevOps para el curso de Herramientas de Desarrollo.

---

## 1. Colaboración de Equipo

### 1.1 Canales Oficiales de Comunicación

Para garantizar una comunicación asíncrona fluida y la resolución ágil de impedimentos, el equipo utiliza los siguientes espacios oficiales:

| Plataforma | Canal / Espacio | Propósito y Dinámica | Audiencia |
| :--- | :--- | :--- | :--- |
| **Slack** | `#anuncios-proyecto` | Comunicados formales, fechas de corte de sprint y entregas. | Todo el equipo |
| **Slack** | `#frontend-dev` | Dudas de maquetación HTML, tokens CSS y diseño responsive. | Desarrolladores Web |
| **Slack** | `#devops-cicd` | Webhook de GitHub Actions: alertas de builds, linters y despliegues. | DevOps / Leads |
| **Slack** | `#bugs-incidentes` | Alertas automáticas de incidencias reportadas desde `contacto.html`. | QA / Desarrolladores |
| **Discord** | `🔊 Daily Standup` | Reunión diaria de sincronización (15 min, 09:00 AM UTC-5). | Equipo Scrum |
| **Discord** | `🔊 Pair Programming` | Salas de co-diseño, depuración en vivo y revisión de Pull Requests. | Parejas de desarrollo |

---

### 1.2 Reglas de Contribución (Contributing Guidelines)

#### A. Estrategia de Ramificación (GitFlow Simplificado)
* `main`: Rama de producción. Código 100% probado, validado y desplegado. **Protegida** contra pushes directos y rebase.
* `develop`: Rama de integración del sprint en curso. Todos los PRs convergen aquí antes de la liberación.
* `feature/<ticket-id>-descripcion-corta`: Nuevas secciones o componentes (ej. `feature/MISTI-104-formulario-incidentes`).
* `bugfix/<ticket-id>-descripcion-corta`: Correcciones de defectos identificados en QA o durante el sprint.
* `hotfix/<ticket-id>-descripcion-corta`: Parches de emergencia para errores críticos en producción (`main`).

#### B. Convención de Commits (Conventional Commits v1.0.0)
Todos los commits deben seguir la estructura: `<tipo>(<alcance opcional>): <descripción imperativa en presente>`

* `feat`: Nueva característica visible para el usuario (ej. `feat(carta): agregar seccion de cafes filtrados`).
* `fix`: Corrección de un fallo (ej. `fix(contacto): corregir padding en formulario movil`).
* `docs`: Cambios en documentación o README (ej. `docs(kanban): actualizar politicas WIP`).
* `style`: Ajustes estéticos, formato o identación sin alterar lógica/diseño visual.
* `refactor`: Reestructuración de HTML/CSS sin cambio de funcionalidad.
* `ci`: Ajustes a workflows de GitHub Actions o scripts de linteo.
* `chore`: Mantenimiento general, actualización de dependencias o assets.

#### C. Flujo de Pull Requests y Code Review
1. Crear la rama desde `develop` actualizada: `git checkout -b feature/MISTI-xxx-nombre develop`.
2. Realizar cambios con commits atómicos y claros.
3. Abrir el **Pull Request** hacia `develop` describiendo:
   - Problema que resuelve y ticket asociado (`Closes #MISTI-xxx`).
   - Capturas de pantalla o comprobación responsive.
4. **Requisitos para Merge:**
   - Superar con éxito todas las comprobaciones del pipeline de **CI (HTML/CSS Linting)**.
   - Contar con al menos **1 aprobación (Code Review LGTM)** de otro miembro del equipo.
   - Sin conflictos con la rama destino.

---

## 2. Gestión de Actividades — Tablero Kanban (Trello / Jira)

El proyecto gestiona su ciclo de vida mediante un tablero Kanban con políticas explícitas y límites de trabajo en curso (WIP - *Work In Progress*).

### 2.1 Políticas del Tablero y Límites WIP

```
+------------------+------------------+------------------+------------------+------------------+
|     BACKLOG      |   TO DO (WIP: 4) |IN PROGRESS(WIP:2)|  REVIEW/QA(WIP:2)|       DONE       |
+------------------+------------------+------------------+------------------+------------------+
| Priorizado según | Listas para      | En desarrollo    | PR abierto y     | Integrado en     |
| valor de negocio | iniciar en el    | activo por el    | validado por CI; | 'main' o         |
| y feedback de    | sprint; cumplen  | responsable.     | revisión de par  | 'develop';       |
| clientes/equipo. | DoR.             | Max 2 en paralelo| en curso.        | cumple DoD.      |
+------------------+------------------+------------------+------------------+------------------+
```

* **Definition of Ready (DoR):** Tarea descrita con claridad, criterios de aceptación definidos, mockup/assets provistos y estimada.
* **Definition of Done (DoD):** Código HTML5/CSS3 validado sin errores sintácticos, responsive verificado (360px a 1440px), PR aprobado y mergeado.

---

### 2.2 Estructura de Tarjetas y Tickets de Trabajo

| Clave | Título / Historia de Usuario | Tipo | Estimación | Asignado | Criterios de Aceptación |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **MISTI-101** | *Catálogo digital de la carta arequipeña* | Historia | 5 SP | Dev Frontend 1 | Desplegar cafés de origen, postres locales y precios usando CSS Grid en `carta.html`. |
| **MISTI-102** | *Diseño responsive móvil en Home y Nosotros* | Tarea | 3 SP | Dev Frontend 2 | Adaptar menú hamburguesa y cuadrículas para anchos `< 768px` sin scroll horizontal. |
| **MISTI-103** | *Formulario de contacto y datos del local* | Historia | 3 SP | Dev Frontend 1 | Formulario funcional con validación HTML5 de correo, teléfono y horario de atención. |
| **MISTI-104** | *Módulo de reporte y seguimiento de bugs* | Historia | 5 SP | Dev Fullstack | Formulario dedicado en `contacto.html` con selectores de módulo, severidad y pasos. |
| **MISTI-105** | *Pipeline de Integración Continua (CI)* | DevOps | 3 SP | DevOps Engineer | Workflow GitHub Actions con validadores de sintaxis HTMLHint y Stylelint en cada push. |
| **MISTI-106** | *Pipeline de Despliegue Continuo (CD)* | DevOps | 2 SP | DevOps Engineer | Publicación automática a GitHub Pages / Vercel al fusionar ramas en `main`. |
| **MISTI-107** | *Bug: Desalineación de botón en pantallas 360px* | Bug | 2 SP | Dev Frontend 2 | Ajustar margen y padding en botón de llamada a la acción en `index.html`. |

---

## 3. Gestión de Proyectos — Cronograma de Sprints e Hitos

El proyecto se ejecuta en un ciclo iterativo de **4 Sprints** de 2 semanas de duración cada uno:

```
[Sprint 0: Setup & DevOps] ---> [Sprint 1: Core Pages] ---> [Sprint 2: Carta & QA] ---> [Sprint 3: CI/CD & Release]
       (Semanas 1-2)                   (Semanas 3-4)                 (Semanas 5-6)                 (Semanas 7-8)
             |                               |                             |                             |
      Hito 1 (Fundación)              Hito 2 (Prototipo)            Hito 3 (Interacción)          Hito 4 (Producción)
```

### 3.1 Cronograma Detallado por Sprint

| Sprint | Período | Objetivo Principal | Entregables Clave |
| :--- | :--- | :--- | :--- |
| **Sprint 0** | Semanas 1 – 2 | Setup de entorno, repositorio y estándares de colaboración. | Estructura base de carpetas, README colaborativo, linters y arquitectura CSS modular. |
| **Sprint 1** | Semanas 3 – 4 | Construcción de identidad de marca y páginas institucionales. | `index.html` (Landing interactiva), `nosotros.html` (Historia y tradición) con diseño responsive. |
| **Sprint 2** | Semanas 5 – 6 | Carta gastronómica completa y módulo de reporte de fallos. | `carta.html` categorizada, `contacto.html` con módulo de reporte de incidencias para QA. |
| **Sprint 3** | Semanas 7 – 8 | Automatización DevOps, auditoría de accesibilidad y release. | GitHub Actions CI/CD activos, validación W3C, despliegue a producción y demo final. |

---

### 3.2 Matriz de Hitos de Entrega (Milestones)

* **Hito 1 (M1) — Fundación y Repositorio Establecido (Fin de Semana 2):**  
  Repositorio Git configurado con reglas de protección de ramas, canales de Slack/Discord activos y tablero Kanban funcional.
* **Hito 2 (M2) — Prototipo Navegable Base (Fin de Semana 4):**  
  Sitio web con navegación fluida entre Inicio y Nosotros, paleta sillar/terracota aplicada y sin errores de consola.
* **Hito 3 (M3) — Experiencia Completa y Sistema de Incidentes (Fin de Semana 6):**  
  Menú digital completo con imágenes optimizadas y formulario para registro de fallos operativos.
* **Hito 4 (M4) — Despliegue en Producción & Entrega Final (Fin de Semana 8):**  
  Página publicada en vivo en GitHub Pages/Vercel con pipeline de CI/CD automatizado y documentación técnica finalizada.

---

## 4. Estructura del Proyecto

```text
CafeteriaArequipa/
├── .github/
│   └── workflows/
│       ├── ci.yml              # Pipeline CI: Validación sintáctica HTML y CSS
│       └── cd-pages.yml        # Pipeline CD: Despliegue continuo a GitHub Pages
├── carta.html                  # Catálogo de especialidades y postres arequipeños
├── contacto.html               # Información de local + Módulo de Seguimiento de Incidentes
├── index.html                  # Página principal de Café Misti
├── nosotros.html               # Historia, tradición y origen del café
├── style.css                   # Sistema de diseño, tokens tipográficos y responsive design
├── vercel.json                 # Configuración de despliegue y headers para Vercel
└── README.md                   # Documentación de equipo, Kanban, Sprints y DevOps
```

---

## 5. Validación y Ejecución Local

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/CafeteriaArequipa.git
   cd CafeteriaArequipa
   ```
2. Abrir en el navegador cualquiera de las páginas:
   ```bash
   # En Windows:
   start index.html
   ```
3. O utilizar la extensión **Live Server** de Visual Studio Code para previsualización en vivo.
