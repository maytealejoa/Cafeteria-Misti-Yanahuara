/**
 * ==============================================================================
 * PROYECTO: CAFÉ MISTI (AREQUIPA) - PLATAFORMA WEB & DEVOPS
 * ARCHIVO: app.js
 * PROPÓSITO: Lógica interactiva para los 6 temas del curso de Herramientas de Desarrollo:
 *   1. Widget en tiempo real del estado del local (Abierto/Cerrado).
 *   2. Modal interactivo de colaboración del equipo de desarrollo.
 *   3. Filtro dinámico de productos en la carta con buscador instantáneo.
 *   4. Sistema interactivo de tickets de incidentes (QA / Soporte) con localStorage.
 * ==============================================================================
 */

// Esperar a que todo el DOM esté cargado antes de ejecutar scripts
document.addEventListener('DOMContentLoaded', () => {
    initShopStatusWidget();
    initMenuFilter();
    initIncidentTracker();
});

/**
 * ------------------------------------------------------------------------------
 * TEMA 5: FUNCIONALIDAD EXTRA CAFETERÍA — WIDGET ESTADO DEL LOCAL (ABIERTO/CERRADO)
 * ------------------------------------------------------------------------------
 * Regla de negocio del Café Misti:
 * - Días de atención: Martes a Domingo (Lunes cerrado por descanso/tueste).
 * - Horario: 8:00 AM (08:00) a 9:00 PM (21:00) hora de Arequipa (UTC-5).
 */
function initShopStatusWidget() {
    const statusWidget = document.getElementById('shop-status-widget');
    if (!statusWidget) return;

    function evaluateSchedule() {
        // Obtenemos la hora local del cliente
        const now = new Date();
        const dayOfWeek = now.getDay(); // 0 = Domingo, 1 = Lunes, ..., 6 = Sábado
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const decimalTime = hours + (minutes / 60);

        // Lunes = 1 (Cerrado)
        const isMonday = (dayOfWeek === 1);
        // Horario de 08:00 a 21:00
        const isWithinHours = (decimalTime >= 8.0 && decimalTime < 21.0);
        const isOpen = (!isMonday && isWithinHours);

        if (isOpen) {
            statusWidget.className = 'shop-status status-open';
            statusWidget.innerHTML = `
                <span class="status-indicator"></span>
                <span><strong>Abierto ahora</strong> · Cierra 9:00 pm</span>
            `;
        } else {
            statusWidget.className = 'shop-status status-closed';
            const nextOpening = isMonday ? 'Abre mañana martes 8:00 am' : 'Abre hoy 8:00 am';
            statusWidget.innerHTML = `
                <span class="status-indicator"></span>
                <span><strong>Cerrado ahora</strong> · ${nextOpening}</span>
            `;
        }
    }

    // Evaluación inicial y actualización automática cada 60 segundos
    evaluateSchedule();
    setInterval(evaluateSchedule, 60000);
}

/**
 * ------------------------------------------------------------------------------
 * TEMA 1 & 2: COLABORACIÓN DE EQUIPO Y GESTIÓN ÁGIL — MODAL DE DESARROLLO
 * ------------------------------------------------------------------------------
 * Permite visualizar el equipo responsable, roles de scrum, canales de comunicación
 * y métricas del Sprint activo sin recargar la página.
 */
function initTeamModal() {
    const modal = document.getElementById('team-modal');
    const openBtns = document.querySelectorAll('.open-team-modal-trigger');
    const closeBtn = document.getElementById('close-team-modal');
    const backdrop = document.querySelector('.modal-backdrop');

    if (!modal) return;

    function openModal() {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Evita scroll de fondo
    }

    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    openBtns.forEach(btn => btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModal();
    }));

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (backdrop) backdrop.addEventListener('click', closeModal);

    // Accesibilidad: cerrar modal con tecla 'Escape'
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
}

/**
 * ------------------------------------------------------------------------------
 * TEMA 5: FUNCIONALIDAD EXTRA CAFETERÍA — FILTRO DE PRODUCTOS EN CARTA
 * ------------------------------------------------------------------------------
 * Permite al comensal filtrar por categoría (Café, Postres, Infusiones) y realizar
 * búsquedas en tiempo real por nombre o ingrediente.
 */
function initMenuFilter() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const searchInput = document.getElementById('menu-search-input');
    const menuItems = document.querySelectorAll('.menu-item');
    const countBadge = document.getElementById('menu-items-count');

    // Solo se ejecuta si estamos en 'carta.html'
    if (menuItems.length === 0) return;

    let activeFilter = 'all';
    let searchQuery = '';

    function applyFilters() {
        let visibleCount = 0;

        menuItems.forEach(item => {
            const itemCategory = item.getAttribute('data-category') || '';
            const itemTitle = (item.querySelector('h3')?.textContent || '').toLowerCase();
            const itemDesc = (item.querySelector('p')?.textContent || '').toLowerCase();

            // Validación de categoría seleccionada
            const matchesCategory = (activeFilter === 'all' || itemCategory === activeFilter);
            // Validación de coincidencia de texto
            const matchesSearch = (searchQuery === '' || itemTitle.includes(searchQuery) || itemDesc.includes(searchQuery));

            if (matchesCategory && matchesSearch) {
                item.style.display = 'grid';
                item.classList.add('item-fade-in');
                visibleCount++;
            } else {
                item.style.display = 'none';
                item.classList.remove('item-fade-in');
            }
        });

        // Ocultar títulos de categorías vacías
        document.querySelectorAll('.menu-category').forEach(categorySection => {
            const hasVisibleItems = Array.from(categorySection.querySelectorAll('.menu-item'))
                .some(it => it.style.display !== 'none');
            categorySection.style.display = hasVisibleItems ? 'grid' : 'none';
        });

        // Actualizar contador informativo
        if (countBadge) {
            countBadge.textContent = `${visibleCount} producto${visibleCount === 1 ? '' : 's'} disponible${visibleCount === 1 ? '' : 's'}`;
        }
    }

    // Eventos en botones de categoría
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeFilter = btn.getAttribute('data-filter') || 'all';
            applyFilters();
        });
    });

    // Eventos en barra de búsqueda
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchQuery = e.target.value.trim().toLowerCase();
            applyFilters();
        });
    }
}


    // Cargar historial previo de tickets almacenados en el navegador
    renderStoredTickets();

    incidentForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // 1. Extraer valores del formulario
        const reporterName = document.getElementById('reporter-name').value.trim();
        const reporterEmail = document.getElementById('reporter-email').value.trim();
        const issueArea = document.getElementById('issue-area').value;
        const severity = document.getElementById('severity').value;
        const environment = document.getElementById('environment').value.trim();
        const issueTitle = document.getElementById('issue-title').value.trim();
        const description = document.getElementById('issue-description').value.trim();

        // 2. Generar Ticket ID único y timestamp
        const randomNum = Math.floor(1000 + Math.random() * 9000);
        const ticketId = `MISTI-TKT-${randomNum}`;
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' });

        // 3. Crear objeto de datos del incidente
        const newTicket = {
            id: ticketId,
            title: issueTitle,
            area: issueArea,
            severity: severity,
            reporter: reporterName,
            email: reporterEmail,
            env: environment,
            desc: description,
            date: timestamp,
            status: 'To Do (Jira Backlog)'
        };

        // 4. Guardar en localStorage
        saveTicketLocally(newTicket);

        // 5. Mostrar feedback visual (Toast / Mensaje)
        showFeedbackToast(ticketId, severity);

        // 6. Limpiar formulario y refrescar lista
        incidentForm.reset();
        renderStoredTickets();
    });

    function saveTicketLocally(ticket) {
        const tickets = JSON.parse(localStorage.getItem('misti_tickets') || '[]');
        tickets.unshift(ticket); // Insertar al inicio
        // Mantener solo los últimos 5 tickets
        if (tickets.length > 5) tickets.pop();
        localStorage.setItem('misti_tickets', JSON.stringify(tickets));
    }

    function renderStoredTickets() {
        if (!ticketsContainer) return;
        const tickets = JSON.parse(localStorage.getItem('misti_tickets') || '[]');

        if (tickets.length === 0) {
            ticketsContainer.innerHTML = `
                <div class="empty-tickets">
                    <p>No se han registrado incidentes en esta sesión. Todo el menú y sitio operan normalmente.</p>
                </div>
            `;
            return;
        }

        ticketsContainer.innerHTML = tickets.map(t => `
            <article class="ticket-card severity-${t.severity}">
                <div class="ticket-header">
                    <span class="ticket-id">#${t.id}</span>
                    <span class="ticket-badge badge-${t.severity}">${t.severity.toUpperCase()}</span>
                    <span class="ticket-time">${t.date}</span>
                </div>
                <h4 class="ticket-title">${escapeHTML(t.title)}</h4>
                <p class="ticket-desc">${escapeHTML(t.desc)}</p>
                <div class="ticket-footer">
                    <span><strong>Área:</strong> ${t.area}</span>
                    <span class="ticket-kanban-status">● ${t.status}</span>
                </div>
            </article>
        `).join('');
    }

    function showFeedbackToast(ticketId, severity) {
        if (!toastNotification) return;

        toastNotification.innerHTML = `
            <div class="toast-content">
                <span class="toast-icon">✓</span>
                <div>
                    <strong>¡Incidente registrado exitosamente!</strong>
                    <p>Ticket <code>#${ticketId}</code> generado y canalizado al tablero Jira / Slack (#bugs-incidentes).</p>
                </div>
            </div>
            <button class="toast-close" onclick="this.parentElement.classList.remove('show')">×</button>
        `;
        toastNotification.className = 'incident-toast show';

        setTimeout(() => {
            toastNotification.classList.remove('show');
        }, 6000);
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }

